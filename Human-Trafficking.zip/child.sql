-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2019 at 04:28 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `child`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(4) NOT NULL,
  `name` varchar(30) NOT NULL,
  `contact` varchar(13) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `contact`, `mail`, `message`) VALUES
(1, 'Anurag Kumar Gupta', '9852423008', 'anraggreat77@gmail.com', 'Wow nice portal for humman Traffikng'),
(2, '', '', '', ''),
(3, 'mamta1', '1234567890', 'anuraggreat77@gmail.com', 'hlo ji');

-- --------------------------------------------------------

--
-- Table structure for table `instant-img`
--

CREATE TABLE `instant-img` (
  `img` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `missing`
--

CREATE TABLE `missing` (
  `id` int(4) NOT NULL,
  `name` varchar(30) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `missing`
--

INSERT INTO `missing` (`id`, `name`, `contact`, `mail`, `state`, `address`, `message`) VALUES
(1, 'Ruby Kumari', '9852423008', 'ruby123@gmail.com', 'Bihar', 'Muzaffarpur Institute of Technology', 'Its a Collage girls student of mit Muzaffarpur lost'),
(2, 'Beauty', '756839475', 'kribeauty@gmail.com', 'Bihar', 'muzaffarpur', 'Beuty  Kumari Missing my group.'),
(3, 'Satyam kumar', '7867853464', 'Satyam123@gmail.com', 'Bihar', 'Mit', 'Hii Dost');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(4) NOT NULL,
  `heading` varchar(300) NOT NULL,
  `story` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `heading`, `story`) VALUES
(2, 'The government needs to do more to protect victims of human trafficking', 'Last week the minister of state for immigration, Caroline Nokes MP, clarified that â€œ479 [potential victims of trafficking] received a positive decision on reasonable grounds during a detention periodâ€ and that â€œ422 people were released within a weekâ€.\r\n\r\nWe believe that the detention of 479 potential victims of trafficking highlights severe flaws in the detention gatekeeping process, which is meant to identify vulnerable people. The failure of UK authorities to protect hundreds of potential victims who have indicators of exploitation, and 29 more whose legal status recognizes them as potential victims, should be cause for investigation and not commendation.'),
(3, 'The South Asian women trafficked to Kenya\'s Bollywood-style bars', 'Nepali beautician Sheela* did not think twice about ditching her salon job when she received a call offering seven times her salary to work as a cultural dancer at a nightclub in Kenya.\r\n\r\nIt did not matter that the 23-year-old woman from a village in the Himalayan foothills had never heard of the East African nation.\r\n\r\nOr that she had no experience as a dancer, had never met the owner of the club and was not shown an employment contract.\r\n\r\nWith elderly parents to care for and medical bills to clear after her brother suffered a motorcycle accident, the offer of a monthly salary of $600, with food, housing and transport costs all covered, was a no-brainer for Sheela.\r\n\r\n\"[But] it was not what I expected,\" said Sheela, who was rescued with 11 other Nepali women from a nightclub in Kenya\'s coastal city of Mombasa in April where she danced on stage from 9pm to 4am getting tips from male clients.\r\n\r\n\"I was told that being escorted everywhere by the driver, not leaving the flat except for ');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `id` int(4) NOT NULL,
  `name` varchar(25) NOT NULL,
  `contact` bigint(13) NOT NULL,
  `date` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`id`, `name`, `contact`, `date`, `time`, `message`) VALUES
(1, 'National Means Cum Merit ', 987654321, '8/26/2019', '12:00am', 'ji'),
(2, 'anurag', 9852423008, '8/27/2019', '12:30am', 'ji'),
(3, 'Anurag Kumar Gupta', 9852423008, '8/12/2019', '12:00am', 'Here one student trafficking by some people'),
(4, 'Ruby Kumari', 9876543210, '', '', 'Wow nice portal for humman Traffikng'),
(5, 'Anurag Kumar Gupta', 9852423008, '', '', 'Hii'),
(6, 'Beauty', 9876544098, '8/13/2019', '12:00am', 'sir here at laxmi chowk,muzaffarpur one child is in problem.');

-- --------------------------------------------------------

--
-- Table structure for table `survey`
--

CREATE TABLE `survey` (
  `id` int(4) NOT NULL,
  `one` varchar(20) NOT NULL,
  `two` varchar(20) NOT NULL,
  `three` varchar(20) NOT NULL,
  `four` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `survey`
--

INSERT INTO `survey` (`id`, `one`, `two`, `three`, `four`) VALUES
(1, 'Very Good', 'Awesome', 'Very Good', 'good'),
(2, 'Awesome', 'Awesome', 'Awesome', 'Very Good'),
(3, 'Very Good', 'Awesome', 'Very Good', 'Awesome'),
(5, 'Simple', 'Good', 'Very Good', 'Awesome'),
(6, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `name`, `password`) VALUES
('anurag', 'anurag', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `missing`
--
ALTER TABLE `missing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `query`
--
ALTER TABLE `query`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey`
--
ALTER TABLE `survey`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `missing`
--
ALTER TABLE `missing`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `query`
--
ALTER TABLE `query`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `survey`
--
ALTER TABLE `survey`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
