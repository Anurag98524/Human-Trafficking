<?php
  $con= mysqli_connect('localhost','root','','child');

    if($con==false)
    {
    	echo "Connection is not done";
    }
   
    	

?>

<?php
if(isset($_POST['submit']))
{
	
	$name=$_POST['name'];
	$contact=$_POST['contact'];
	$mail=$_POST['mail'];
	
	$message=$_POST['message'];
	
  
	
	$qry="INSERT INTO  feedback (name, contact, mail, message) VALUES ('$name','$contact','$mail','$message')";
	$run=mysqli_query($con,$qry);	
	
	
	
	
	if($run==true)
	  {
		
		?>
		<script>
			alert('Thanks For FeedBack');
			window.open('index.php','_self');

		</script>
		<?php
		
	   }

}
?>





