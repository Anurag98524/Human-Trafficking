<?php
  $con= mysqli_connect('localhost','root','','child');

    if($con==false)
    {
    	echo "Connection is not done";
    }
   
    	

?>

<?php
if(isset($_POST['submit']))
{
	
	$heading=$_POST['heading'];
	$story=$_POST['story'];
	
	
  
	
	$qry="INSERT INTO  news (heading, story) VALUES ('$heading','$story')";
	$run=mysqli_query($con,$qry);	
	
	
	
	
	if($run==true)
	  {
		
		?>
		<script>
			alert('News upload Sucessful');
			window.open('admin-page.php','_self');

		</script>
		<?php
		
	   }

}
?>





