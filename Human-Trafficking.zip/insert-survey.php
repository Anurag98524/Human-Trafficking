<?php
  $con= mysqli_connect('localhost','root','','child');

    if($con==false)
    {
    	echo "Connection is not done";
    }
   
    	

?>

<?php
if(isset($_POST['submit']))
{
	
	$one=$_POST['one'];
	$two=$_POST['two'];
	$three=$_POST['three'];
	
	$four=$_POST['four'];
	
  
	
	$qry="INSERT INTO  survey (one, two, three, four) VALUES ('$one','$two','$three','$four')";
	$run=mysqli_query($con,$qry);	
	
	
	
	
	if($run==true)
	  {
		
		?>
		<script>
			alert('Thanks For Survey my portal');
			window.open('index.php','_self');

		</script>
		<?php
		
	   }

}
?>





