<?php
  $con= mysqli_connect('localhost','root','','child');

    if($con==false)
    {
    	echo "Connection is not done";
    }
   
    	

?>

<?php
if(isset($_POST['submit']))
{
	
	$name=$_POST['name'];
	$contact=$_POST['contact'];
	$mail=$_POST['mail'];
    $state=$_POST['state'];
	$address=$_POST['address'];
	$message=$_POST['message'];
	
  
	
	$qry="INSERT INTO  missing (name, contact, mail, state, address, message) VALUES ('$name','$contact','$mail','$state','$address','$message')";
	$run=mysqli_query($con,$qry);	
	
	
	
	
	if($run==true)
	  {
		
		?>
		<script>
			alert('Thanks For Submission');
			window.open('index.php','_self');

		</script>
		<?php
		
	   }

}
?>





