<?php
  $con= mysqli_connect('localhost','root','','child');

    if($con==false)
    {
    	echo "Connection is not done";
    }
   
    	

?>

<?php
if(isset($_POST['submit']))
{
	
	$name=$_POST['name'];
	$contact=$_POST['contact'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$message=$_POST['message'];
	
  
	
	$qry="INSERT INTO query (name, contact, date, time, message) VALUES ('$name','$contact','$date','$time','$message')";
	$run=mysqli_query($con,$qry);	
	
	
	
	
	if($run==true)
	  {
		
		?>
		<script>
			alert('Thanks for droping Message');
			window.open('index.php','_self');

		</script>
		<?php
		
	   }

}
?>





